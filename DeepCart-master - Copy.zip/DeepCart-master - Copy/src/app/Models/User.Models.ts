export interface Registration
{
   
    UserName:string;
    Password:string;
    Email:string;
    Phone:string;
}